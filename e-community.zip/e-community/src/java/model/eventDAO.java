package model;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class eventDAO {
    
    // No constructor needed - we'll use DBConnection.getConnection()
    
    // Method to count total events for the Dashboard
    public int getTotalEventCount() {
        int count = 0;
        String query = "SELECT COUNT(*) FROM APP.PROGRAMS";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {
            
            if (rs.next()) {
                count = rs.getInt(1);
            }
            System.out.println("EVENT COUNT FROM DB = " + count);
        } catch (SQLException e) {
            System.err.println("ERROR in getTotalEventCount: " + e.getMessage());
            e.printStackTrace();
        }
        return count;
    }
    
    // Create: Function to add a new event
    public boolean addEvent(Event event) {
        String query = "INSERT INTO APP.PROGRAMS (TITLE, EVENT_DATE, DESCRIPTION, LOCATION, EVENT_HOURS) VALUES (?, ?, ?, ?, ?)";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            
            ps.setString(1, event.getEventName());
            ps.setString(2, event.getEventDate());
            ps.setString(3, event.getDescription() != null ? event.getDescription() : "");
            ps.setString(4, event.getLocation() != null ? event.getLocation() : "General");
            ps.setDouble(5, event.getEventHours());
            
            System.out.println("DEBUG: Adding event - Name: " + event.getEventName() + 
                              ", Location: " + event.getLocation() + 
                              ", Hours: " + event.getEventHours());
            
            int rows = ps.executeUpdate();
            System.out.println("DEBUG: Rows affected: " + rows);
            return rows > 0;
        } catch (Exception e) {
            System.err.println("ERROR in addEvent: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    // Get all events
    public List<Event> getAllEvents() {
        List<Event> list = new ArrayList<>();
        String sql = "SELECT ID, TITLE, EVENT_DATE, DESCRIPTION, LOCATION, EVENT_HOURS FROM APP.PROGRAMS ORDER BY EVENT_DATE ASC";
        
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Event e = new Event();
                e.setId(rs.getInt("ID"));
                e.setEventName(rs.getString("TITLE"));
                e.setEventDate(rs.getString("EVENT_DATE"));
                e.setDescription(rs.getString("DESCRIPTION"));
                e.setLocation(rs.getString("LOCATION"));
                e.setEventHours(rs.getDouble("EVENT_HOURS"));
                
                System.out.println("DEBUG: Event " + e.getId() + " - " + e.getEventName() + 
                                  ", Location: " + e.getLocation() + 
                                  ", Hours: " + e.getEventHours());
                
                list.add(e);
            }
        } catch (SQLException e) {
            System.err.println("ERROR in getAllEvents: " + e.getMessage());
            e.printStackTrace();
        }
        return list;
    }
    
    // Get event by ID
    public Event getEventById(int eventId) {
        Event event = null;
        String sql = "SELECT ID, TITLE, EVENT_DATE, DESCRIPTION, LOCATION, EVENT_HOURS FROM APP.PROGRAMS WHERE ID = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, eventId);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                event = new Event();
                event.setId(rs.getInt("ID"));
                event.setEventName(rs.getString("TITLE"));
                event.setEventDate(rs.getString("EVENT_DATE"));
                event.setDescription(rs.getString("DESCRIPTION"));
                event.setLocation(rs.getString("LOCATION"));
                event.setEventHours(rs.getDouble("EVENT_HOURS"));
                
                System.out.println("DEBUG getEventById: Event " + eventId + 
                                  ", Name: " + event.getEventName() + 
                                  ", Location: " + event.getLocation() + 
                                  ", Hours: " + event.getEventHours());
            }
            
        } catch (SQLException e) {
            System.err.println("ERROR in getEventById: " + e.getMessage());
            e.printStackTrace();
        }
        return event;
    }
    
    // Update event
    public boolean updateEvent(Event event) {
        String query = "UPDATE APP.PROGRAMS SET TITLE = ?, EVENT_DATE = ?, DESCRIPTION = ?, LOCATION = ?, EVENT_HOURS = ? WHERE ID = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            
            ps.setString(1, event.getEventName());
            ps.setString(2, event.getEventDate());
            ps.setString(3, event.getDescription() != null ? event.getDescription() : "");
            ps.setString(4, event.getLocation() != null ? event.getLocation() : "General");
            ps.setDouble(5, event.getEventHours());
            ps.setInt(6, event.getId());
            
            int rows = ps.executeUpdate();
            System.out.println("Updated event ID " + event.getId() + ", rows affected: " + rows);
            return rows > 0;
            
        } catch (Exception e) {
            System.err.println("ERROR in updateEvent: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    // Delete event
    public boolean deleteEvent(int eventId) {
        String sql = "DELETE FROM APP.PROGRAMS WHERE ID = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, eventId);
            int rows = ps.executeUpdate();
            System.out.println("Deleted event ID " + eventId + ", rows affected: " + rows);
            return rows > 0;
            
        } catch (SQLException e) {
            System.err.println("ERROR in deleteEvent: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    // Simple delete event (for backward compatibility)
    public boolean deleteEventSimple(int eventId) {
        return deleteEvent(eventId);
    }
    
    // Check if event exists
    public boolean eventExists(int eventId) {
        String sql = "SELECT COUNT(*) FROM APP.PROGRAMS WHERE ID = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, eventId);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            System.err.println("ERROR in eventExists: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }
}