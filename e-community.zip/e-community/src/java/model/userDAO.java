package model;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class userDAO {
    private Connection con;
    
    // Default constructor - for most servlets
    public userDAO() {
        try {
            this.con = DBConnection.getConnection();
        } catch (Exception e) {
            System.err.println("ERROR creating userDAO: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    // Constructor with connection - for backward compatibility
    public userDAO(Connection con) {
        this.con = con;
    }
    
    // User Registration
    public boolean register(String fullName, String email, String password) {
        String sql = "INSERT INTO APP.USERS (FULL_NAME, EMAIL, PASSWORD, ROLE) VALUES (?, ?, ?, 'Volunteer')";
        
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, fullName);
            ps.setString(2, email);
            ps.setString(3, password);
            
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("ERROR in register: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    // Check if email exists
    public boolean emailExists(String email) {
        String sql = "SELECT COUNT(*) FROM APP.USERS WHERE EMAIL = ?";
        
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            
            return rs.next() && rs.getInt(1) > 0;
        } catch (SQLException e) {
            System.err.println("ERROR in emailExists: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    // User Login
    public User login(String email, String password) {
        User user = null;
        String sql = "SELECT * FROM APP.USERS WHERE EMAIL = ? AND PASSWORD = ?";
        
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, email);
            ps.setString(2, password);
            
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                user = new User();
                user.setId(rs.getInt("ID"));
                user.setFullName(rs.getString("FULL_NAME"));
                user.setEmail(rs.getString("EMAIL"));
                user.setRole(rs.getString("ROLE"));
                System.out.println("Login successful for: " + email);
            }
        } catch (SQLException e) {
            System.err.println("ERROR in login: " + e.getMessage());
            e.printStackTrace();
        }
        return user;
    }
    
    // Get total volunteer count
    public int getVolunteerCount() {
        int count = 0;
        String sql = "SELECT COUNT(*) FROM APP.USERS WHERE ROLE = 'Volunteer' OR ROLE IS NULL";
        
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            if (rs.next()) {
                count = rs.getInt(1);
                System.out.println("DEBUG: Found " + count + " volunteers in users table");
            }
        } catch (SQLException e) {
            System.err.println("ERROR in getVolunteerCount: " + e.getMessage());
            e.printStackTrace();
        }
        return count;
    }
    
    // Get total user count
    public int getUserCount() {
        int count = 0;
        String sql = "SELECT COUNT(*) FROM APP.USERS";
        
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            if (rs.next()) {
                count = rs.getInt(1);
            }
        } catch (SQLException e) {
            System.err.println("ERROR in getUserCount: " + e.getMessage());
            e.printStackTrace();
        }
        return count;
    }
    
    // Register user for event
    public boolean registerForEvent(int userId, int programId) {
        // First check if already registered
        if (isAlreadyRegistered(userId, programId)) {
            System.out.println("User " + userId + " already registered for event " + programId);
            return false;
        }
        
        String sql = "INSERT INTO APP.REGISTRATIONS (USER_ID, PROGRAM_ID, REGISTERED_AT, ATTENDANCE_STATUS) VALUES (?, ?, CURRENT_TIMESTAMP, 'Registered')";
        
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, programId);
            
            boolean success = ps.executeUpdate() > 0;
            if (success) {
                System.out.println("User " + userId + " registered for event " + programId);
            }
            return success;
        } catch (SQLException e) {
            System.err.println("ERROR in registerForEvent: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    // Check if user is already registered for event (ACTIVE registrations only)
public boolean isAlreadyRegistered(int userId, int programId) {
    String sql = "SELECT COUNT(*) FROM APP.REGISTRATIONS WHERE USER_ID = ? AND PROGRAM_ID = ? AND ATTENDANCE_STATUS != 'Cancelled'";
    
    try (PreparedStatement ps = con.prepareStatement(sql)) {
        ps.setInt(1, userId);
        ps.setInt(2, programId);
        
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            return rs.getInt(1) > 0;
        }
    } catch (SQLException e) {
        System.err.println("ERROR in isAlreadyRegistered: " + e.getMessage());
        e.printStackTrace();
    }
    return false;
}
    
    // Get events that user has registered for
public List<Map<String, Object>> getUserEvents(int userId) {
    List<Map<String, Object>> events = new ArrayList<>();
    
    String sql = "SELECT r.ID as registration_id, p.ID as event_id, p.TITLE, " +
                 "p.EVENT_DATE, p.LOCATION, p.EVENT_HOURS, r.ATTENDANCE_STATUS, " +
                 "r.REGISTERED_AT " +
                 "FROM APP.REGISTRATIONS r " +
                 "JOIN APP.PROGRAMS p ON r.PROGRAM_ID = p.ID " +
                 "WHERE r.USER_ID = ? " +
                 "ORDER BY p.EVENT_DATE ASC";
    
    try (PreparedStatement ps = con.prepareStatement(sql)) {
        ps.setInt(1, userId);
        ResultSet rs = ps.executeQuery();
        
        while (rs.next()) {
            Map<String, Object> event = new HashMap<>();
            event.put("registrationId", rs.getInt("registration_id"));
            event.put("eventId", rs.getInt("event_id"));
            event.put("title", rs.getString("TITLE"));
            event.put("date", rs.getString("EVENT_DATE"));
            event.put("location", rs.getString("LOCATION"));
            
            // Get EVENT_HOURS - important fix
            double hours = 0.0;
            try {
                hours = rs.getDouble("EVENT_HOURS");
                if (rs.wasNull()) {
                    hours = 2.0; // Default value
                }
            } catch (SQLException e) {
                System.out.println("EVENT_HOURS column error, using default");
                hours = 2.0;
            }
            event.put("hours", hours);
            
            event.put("status", rs.getString("ATTENDANCE_STATUS"));
            event.put("registeredDate", rs.getTimestamp("REGISTERED_AT"));
            
            // Determine if event is upcoming or past
            try {
                java.sql.Date eventDate = rs.getDate("EVENT_DATE");
                if (eventDate != null) {
                    java.util.Date today = new java.util.Date();
                    boolean isUpcoming = eventDate.after(new java.sql.Date(today.getTime()));
                    event.put("isUpcoming", isUpcoming);
                } else {
                    event.put("isUpcoming", false);
                }
            } catch (Exception e) {
                event.put("isUpcoming", false);
            }
            
            System.out.println("DEBUG getUserEvents: " + rs.getString("TITLE") + 
                              ", Location: " + rs.getString("LOCATION") + 
                              ", Hours: " + hours);
            events.add(event);
        }
        System.out.println("DEBUG: Retrieved " + events.size() + " events for user " + userId);
        
    } catch (SQLException e) {
        System.err.println("ERROR in getUserEvents: " + e.getMessage());
        e.printStackTrace();
    }
    return events;
}
    
    // Get upcoming events count for user
    public int getUserUpcomingEventsCount(int userId) {
        int count = 0;
        
        String sql = "SELECT COUNT(*) FROM APP.REGISTRATIONS r " +
                     "JOIN APP.PROGRAMS p ON r.PROGRAM_ID = p.ID " +
                     "WHERE r.USER_ID = ? AND p.EVENT_DATE >= CURRENT_DATE";
        
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                count = rs.getInt(1);
            }
        } catch (SQLException e) {
            System.err.println("ERROR in getUserUpcomingEventsCount: " + e.getMessage());
            e.printStackTrace();
        }
        return count;
    }
    
    // Verify if registration belongs to user
    public boolean verifyUserRegistration(int userId, int registrationId) {
        String sql = "SELECT COUNT(*) FROM APP.REGISTRATIONS WHERE ID = ? AND USER_ID = ?";
        
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, registrationId);
            ps.setInt(2, userId);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                boolean exists = rs.getInt(1) > 0;
                System.out.println("DEBUG: verifyUserRegistration - User " + userId + 
                                 ", Registration " + registrationId + " = " + exists);
                return exists;
            }
        } catch (SQLException e) {
            System.err.println("ERROR in verifyUserRegistration: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }
    
    // Cancel registration
    public boolean cancelRegistration(int registrationId) {
        String sql = "UPDATE APP.REGISTRATIONS SET ATTENDANCE_STATUS = 'Cancelled' WHERE ID = ?";
        
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, registrationId);
            boolean success = ps.executeUpdate() > 0;
            System.out.println("DEBUG: cancelRegistration " + registrationId + " = " + success);
            return success;
        } catch (SQLException e) {
            System.err.println("ERROR in cancelRegistration: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    // Update attendance status
    public boolean updateAttendance(int registrationId, int userId, String status) {
        // First verify ownership
        if (!verifyUserRegistration(userId, registrationId)) {
            System.out.println("DEBUG: updateAttendance - Not authorized for registration " + registrationId);
            return false;
        }
        
        String sql = "UPDATE APP.REGISTRATIONS SET ATTENDANCE_STATUS = ? WHERE ID = ?";
        
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setInt(2, registrationId);
            boolean success = ps.executeUpdate() > 0;
            System.out.println("DEBUG: updateAttendance " + registrationId + " to " + status + " = " + success);
            return success;
        } catch (SQLException e) {
            System.err.println("ERROR in updateAttendance: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    // Get user's total volunteer hours
    public double getUserTotalHours(int userId) {
        double totalHours = 0;
        
        String sql = "SELECT COALESCE(SUM(p.EVENT_HOURS), 0) " +
                     "FROM APP.REGISTRATIONS r " +
                     "JOIN APP.PROGRAMS p ON r.PROGRAM_ID = p.ID " +
                     "WHERE r.USER_ID = ? AND r.ATTENDANCE_STATUS = 'Attended'";
        
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                totalHours = rs.getDouble(1);
            }
        } catch (SQLException e) {
            System.err.println("ERROR in getUserTotalHours: " + e.getMessage());
            e.printStackTrace();
        }
        return totalHours;
    }
    
    // Update user profile
    // Update profile with address only (remove phone)
public boolean updateProfile(int userId, String fullName, String email, String address) {
    String sql = "UPDATE APP.USERS SET FULL_NAME = ?, EMAIL = ?";
    
    // Check if address column exists
    boolean hasAddressColumn = false;
    
    try {
        DatabaseMetaData meta = con.getMetaData();
        ResultSet columns = meta.getColumns(null, "APP", "USERS", "ADDRESS");
        hasAddressColumn = columns.next();
        columns.close();
    } catch (SQLException e) {
        System.out.println("Checking address column: " + e.getMessage());
    }
    
    if (hasAddressColumn) sql += ", ADDRESS = ?";
    
    sql += " WHERE ID = ?";
    
    try (PreparedStatement ps = con.prepareStatement(sql)) {
        int paramIndex = 1;
        ps.setString(paramIndex++, fullName);
        ps.setString(paramIndex++, email);
        
        if (hasAddressColumn) {
            ps.setString(paramIndex++, address != null ? address : "");
        }
        
        ps.setInt(paramIndex, userId);
        
        boolean success = ps.executeUpdate() > 0;
        System.out.println("Profile update for user " + userId + ": " + success);
        return success;
    } catch (SQLException e) {
        System.err.println("ERROR in updateProfile: " + e.getMessage());
        e.printStackTrace();
        return false;
    }
}
    
    // Get user by ID with all fields
public User getUserById(int userId) {
    User user = null;
    String sql = "SELECT * FROM APP.USERS WHERE ID = ?";
    
    try (PreparedStatement ps = con.prepareStatement(sql)) {
        ps.setInt(1, userId);
        ResultSet rs = ps.executeQuery();
        
        if (rs.next()) {
            user = new User();
            user.setId(rs.getInt("ID"));
            user.setFullName(rs.getString("FULL_NAME"));
            user.setEmail(rs.getString("EMAIL"));
            user.setRole(rs.getString("ROLE"));
            
            // Try to get additional fields if they exist
            try {
                // Check if phone column exists
                String phone = rs.getString("PHONE");
                // You might want to store this in the User object or a Map
            } catch (SQLException e) {
                // Column doesn't exist, ignore
            }
            
            try {
                // Check if address column exists
                String address = rs.getString("ADDRESS");
                // You might want to store this in the User object or a Map
            } catch (SQLException e) {
                // Column doesn't exist, ignore
            }
        }
    } catch (SQLException e) {
        System.err.println("ERROR in getUserById: " + e.getMessage());
        e.printStackTrace();
    }
    return user;
}
    
    // Check if user has a cancelled registration for the event
public boolean hasCancelledRegistration(int userId, int programId) {
    String sql = "SELECT COUNT(*) FROM APP.REGISTRATIONS WHERE USER_ID = ? AND PROGRAM_ID = ? AND ATTENDANCE_STATUS = 'Cancelled'";
    
    try (PreparedStatement ps = con.prepareStatement(sql)) {
        ps.setInt(1, userId);
        ps.setInt(2, programId);
        
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            return rs.getInt(1) > 0;
        }
    } catch (SQLException e) {
        System.err.println("ERROR in hasCancelledRegistration: " + e.getMessage());
        e.printStackTrace();
    }
    return false;
}

// Get user's registration for a specific event
public Map<String, Object> getUserEventRegistration(int userId, int programId) {
    Map<String, Object> registration = new HashMap<>();
    String sql = "SELECT ID as registration_id, ATTENDANCE_STATUS as status FROM APP.REGISTRATIONS WHERE USER_ID = ? AND PROGRAM_ID = ?";
    
    try (PreparedStatement ps = con.prepareStatement(sql)) {
        ps.setInt(1, userId);
        ps.setInt(2, programId);
        
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            registration.put("registrationId", rs.getInt("registration_id"));
            registration.put("status", rs.getString("status"));
            return registration;
        }
    } catch (SQLException e) {
        System.err.println("ERROR in getUserEventRegistration: " + e.getMessage());
        e.printStackTrace();
    }
    return null;
}

// Reactivate a cancelled registration
public boolean reactivateRegistration(int userId, int programId) {
    String sql = "UPDATE APP.REGISTRATIONS SET ATTENDANCE_STATUS = 'Registered', REGISTERED_AT = CURRENT_TIMESTAMP WHERE USER_ID = ? AND PROGRAM_ID = ? AND ATTENDANCE_STATUS = 'Cancelled'";
    
    try (PreparedStatement ps = con.prepareStatement(sql)) {
        ps.setInt(1, userId);
        ps.setInt(2, programId);
        
        boolean success = ps.executeUpdate() > 0;
        if (success) {
            System.out.println("Reactivated registration for user " + userId + " in event " + programId);
        }
        return success;
    } catch (SQLException e) {
        System.err.println("ERROR in reactivateRegistration: " + e.getMessage());
        e.printStackTrace();
        return false;
    }
}

// Verify user's current password
public boolean verifyPassword(int userId, String password) {
    String sql = "SELECT COUNT(*) FROM APP.USERS WHERE ID = ? AND PASSWORD = ?";
    
    try (PreparedStatement ps = con.prepareStatement(sql)) {
        ps.setInt(1, userId);
        ps.setString(2, password);
        
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            return rs.getInt(1) > 0;
        }
    } catch (SQLException e) {
        System.err.println("ERROR in verifyPassword: " + e.getMessage());
        e.printStackTrace();
    }
    return false;
}

// Update password
public boolean updatePassword(int userId, String newPassword) {
    String sql = "UPDATE APP.USERS SET PASSWORD = ? WHERE ID = ?";
    
    try (PreparedStatement ps = con.prepareStatement(sql)) {
        ps.setString(1, newPassword);
        ps.setInt(2, userId);
        
        return ps.executeUpdate() > 0;
    } catch (SQLException e) {
        System.err.println("ERROR in updatePassword: " + e.getMessage());
        e.printStackTrace();
        return false;
    }
}

// Update attendance status
public boolean updateAttendance(int registrationId, String status) {
    String sql = "UPDATE APP.REGISTRATIONS SET ATTENDANCE_STATUS = ? WHERE ID = ?";
    
    try (PreparedStatement ps = con.prepareStatement(sql)) {
        ps.setString(1, status);
        ps.setInt(2, registrationId);
        
        boolean success = ps.executeUpdate() > 0;
        System.out.println("DEBUG: updateAttendance " + registrationId + " to " + status + " = " + success);
        return success;
    } catch (SQLException e) {
        System.err.println("ERROR in updateAttendance: " + e.getMessage());
        e.printStackTrace();
        return false;
    }
}

// Get event hours by registration ID
public double getEventHoursByRegistration(int registrationId) {
    double hours = 0.0;
    String sql = "SELECT p.EVENT_HOURS FROM APP.REGISTRATIONS r " +
                 "JOIN APP.PROGRAMS p ON r.PROGRAM_ID = p.ID " +
                 "WHERE r.ID = ?";
    
    try (PreparedStatement ps = con.prepareStatement(sql)) {
        ps.setInt(1, registrationId);
        ResultSet rs = ps.executeQuery();
        
        if (rs.next()) {
            hours = rs.getDouble("EVENT_HOURS");
        }
    } catch (SQLException e) {
        System.err.println("ERROR in getEventHoursByRegistration: " + e.getMessage());
        e.printStackTrace();
    }
    return hours;
}

// Update user's total hours (if you have a HOURS_VOLUNTEERED column in USERS table)
public boolean updateUserHours(int userId, double additionalHours) {
    // Check if HOURS_VOLUNTEERED column exists
    boolean hasHoursColumn = false;
    try {
        DatabaseMetaData meta = con.getMetaData();
        ResultSet columns = meta.getColumns(null, "APP", "USERS", "HOURS_VOLUNTEERED");
        hasHoursColumn = columns.next();
        columns.close();
    } catch (SQLException e) {
        System.out.println("Checking HOURS_VOLUNTEERED column: " + e.getMessage());
    }
    
    if (!hasHoursColumn) {
        // Column doesn't exist, we'll calculate hours dynamically
        return true;
    }
    
    String sql = "UPDATE APP.USERS SET HOURS_VOLUNTEERED = COALESCE(HOURS_VOLUNTEERED, 0) + ? WHERE ID = ?";
    
    try (PreparedStatement ps = con.prepareStatement(sql)) {
        ps.setDouble(1, additionalHours);
        ps.setInt(2, userId);
        
        return ps.executeUpdate() > 0;
    } catch (SQLException e) {
        System.err.println("ERROR in updateUserHours: " + e.getMessage());
        e.printStackTrace();
        return false;
    }
}

// Get user's total attended hours (dynamic calculation - preferred method)
public double getUserTotalAttendedHours(int userId) {
    double totalHours = 0.0;
    
    String sql = "SELECT COALESCE(SUM(p.EVENT_HOURS), 0) as total_hours " +
                 "FROM APP.REGISTRATIONS r " +
                 "JOIN APP.PROGRAMS p ON r.PROGRAM_ID = p.ID " +
                 "WHERE r.USER_ID = ? AND r.ATTENDANCE_STATUS = 'Attended'";
    
    try (PreparedStatement ps = con.prepareStatement(sql)) {
        ps.setInt(1, userId);
        ResultSet rs = ps.executeQuery();
        
        if (rs.next()) {
            totalHours = rs.getDouble("total_hours");
        }
    } catch (SQLException e) {
        System.err.println("ERROR in getUserTotalAttendedHours: " + e.getMessage());
        e.printStackTrace();
    }
    return totalHours;
}

// Get user's event statistics
public Map<String, Object> getUserEventStats(int userId) {
    Map<String, Object> stats = new HashMap<>();
    
    String sql = "SELECT " +
                 "COUNT(*) as total_events, " +
                 "SUM(CASE WHEN ATTENDANCE_STATUS = 'Attended' THEN 1 ELSE 0 END) as attended_events, " +
                 "SUM(CASE WHEN ATTENDANCE_STATUS = 'No-Show' THEN 1 ELSE 0 END) as noshow_events, " +
                 "SUM(CASE WHEN ATTENDANCE_STATUS = 'Cancelled' THEN 1 ELSE 0 END) as cancelled_events, " +
                 "COALESCE(SUM(CASE WHEN ATTENDANCE_STATUS = 'Attended' THEN p.EVENT_HOURS ELSE 0 END), 0) as total_hours " +
                 "FROM APP.REGISTRATIONS r " +
                 "LEFT JOIN APP.PROGRAMS p ON r.PROGRAM_ID = p.ID " +
                 "WHERE r.USER_ID = ?";
    
    try (PreparedStatement ps = con.prepareStatement(sql)) {
        ps.setInt(1, userId);
        ResultSet rs = ps.executeQuery();
        
        if (rs.next()) {
            stats.put("totalEvents", rs.getInt("total_events"));
            stats.put("attendedEvents", rs.getInt("attended_events"));
            stats.put("noShowEvents", rs.getInt("noshow_events"));
            stats.put("cancelledEvents", rs.getInt("cancelled_events"));
            stats.put("totalHours", rs.getDouble("total_hours"));
            
            // Calculate upcoming events
            String upcomingSql = "SELECT COUNT(*) as upcoming_events " +
                                "FROM APP.REGISTRATIONS r " +
                                "JOIN APP.PROGRAMS p ON r.PROGRAM_ID = p.ID " +
                                "WHERE r.USER_ID = ? AND r.ATTENDANCE_STATUS = 'Registered' " +
                                "AND p.EVENT_DATE >= CURRENT_DATE";
            
            try (PreparedStatement ps2 = con.prepareStatement(upcomingSql)) {
                ps2.setInt(1, userId);
                ResultSet rs2 = ps2.executeQuery();
                if (rs2.next()) {
                    stats.put("upcomingEvents", rs2.getInt("upcoming_events"));
                }
            }
        }
    } catch (SQLException e) {
        System.err.println("ERROR in getUserEventStats: " + e.getMessage());
        e.printStackTrace();
    }
    
    return stats;
}

    
    // Close connection (optional)
    public void close() {
        if (con != null) {
            try {
                con.close();
                System.out.println("DEBUG: userDAO connection closed");
            } catch (SQLException e) {
                System.err.println("ERROR closing connection: " + e.getMessage());
            }
        }
    }
}