package controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import model.Event;
import model.User;
import model.eventDAO;
import model.userDAO;

@WebServlet("/eventServlet")
public class eventServlet extends HttpServlet {

    // Handles Viewing the List and Deleting (Actions triggered by links)
    // In eventServlet.java - doGet method
@Override
protected void doGet(HttpServletRequest request, HttpServletResponse response) 
        throws ServletException, IOException {
    
    String action = request.getParameter("action");
    eventDAO dao = new eventDAO();

    if ("delete".equals(action)) {
        int id = Integer.parseInt(request.getParameter("id"));
        dao.deleteEvent(id);
        response.sendRedirect("eventServlet?action=list");
    } else {
        // Default action: Fetch from PROGRAMS table and show event_list.jsp
        List<Event> events = dao.getAllEvents();
        request.setAttribute("events", events);
        
        // Get current user's joined events to disable join buttons
        HttpSession session = request.getSession(false);
        if (session != null) {
            User currentUser = (User) session.getAttribute("currentUser");
            if (currentUser != null) {
                userDAO uDao = new userDAO();
                List<Map<String, Object>> joinedEvents = uDao.getUserEvents(currentUser.getId());
                request.setAttribute("joinedEvents", joinedEvents);
            }
        }
        
        request.getRequestDispatcher("event_list.jsp").forward(request, response);
    }
}

// In eventServlet.java - doPost method
@Override
protected void doPost(HttpServletRequest request, HttpServletResponse response) 
        throws ServletException, IOException {
    
    // 1. Get data from the form
    String name = request.getParameter("eventName");
    String date = request.getParameter("eventDate");
    String location = request.getParameter("location");
    String desc = request.getParameter("description");
    String hoursParam = request.getParameter("eventHours");
    
    // DEBUG: Print all parameters
    System.out.println("=== DEBUG: Event Creation Form Data ===");
    System.out.println("Event Name: " + name);
    System.out.println("Event Date: " + date);
    System.out.println("Location: " + location);
    System.out.println("Description: " + desc);
    System.out.println("Event Hours (raw): " + hoursParam);
    
    double eventHours = 2.0; // default
    try {
        eventHours = Double.parseDouble(hoursParam);
        System.out.println("Event Hours (parsed): " + eventHours);
    } catch (NumberFormatException e) {
        System.err.println("Error parsing eventHours: " + hoursParam);
        e.printStackTrace();
    }

    // 2. Populate the JavaBean
    Event newEvent = new Event();
    newEvent.setEventName(name);
    newEvent.setEventDate(date);
    newEvent.setDescription(desc);
    newEvent.setLocation(location);
    newEvent.setEventHours(eventHours);
    
    System.out.println("Event object created: " + newEvent);

    // 3. Use DAO to save to database
    eventDAO dao = new eventDAO();
    boolean success = dao.addEvent(newEvent);

    // 4. Redirect
    if (success) {
        System.out.println("Event saved successfully");
        response.sendRedirect("eventServlet?action=list"); 
    } else {
        System.out.println("Event save failed");
        request.setAttribute("message", "Error adding event.");
        request.getRequestDispatcher("event_create.jsp").forward(request, response);
    }
}
}