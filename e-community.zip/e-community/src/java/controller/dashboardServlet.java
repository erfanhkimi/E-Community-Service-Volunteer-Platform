package controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import model.User;
import model.eventDAO;
import model.userDAO;
import model.volunteerDAO;

@WebServlet("/dashboard")
public class dashboardServlet extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
        throws ServletException, IOException {
    
    HttpSession session = request.getSession(false);
    if (session == null || session.getAttribute("currentUser") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
    
    User user = (User) session.getAttribute("currentUser");
    
    try {
        eventDAO eDao = new eventDAO();
        volunteerDAO vDao = new volunteerDAO();
        userDAO uDao = new userDAO();
        
        // Get dashboard statistics
        int totalEvents = eDao.getTotalEventCount();
        int totalUsers = vDao.getUserCount();
        int totalHours = vDao.getTotalHours();
        
        // Get user's events
        List<Map<String, Object>> userEvents = uDao.getUserEvents(user.getId());
        int upcomingEventsCount = uDao.getUserUpcomingEventsCount(user.getId());
        
        // Set request attributes
        request.setAttribute("eventCount", totalEvents);
        request.setAttribute("userCount", totalUsers);
        request.setAttribute("hourCount", totalHours);
        request.setAttribute("userEvents", userEvents);
        request.setAttribute("upcomingEventsCount", upcomingEventsCount);
        request.setAttribute("myEventsCount", userEvents.size());
        
        // Debug
        System.out.println("User " + user.getFullName() + " has " + 
                          userEvents.size() + " registered events");
        
        request.getRequestDispatcher("dashboard.jsp").forward(request, response);
        
    } catch (Exception e) {
        e.printStackTrace();
        request.setAttribute("error", "Error loading dashboard");
        request.getRequestDispatcher("dashboard.jsp").forward(request, response);
    }
}
}