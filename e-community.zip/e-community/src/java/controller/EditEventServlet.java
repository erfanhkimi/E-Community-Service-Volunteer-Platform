package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import model.Event;
import model.User;
import model.eventDAO;

@WebServlet("/editEvent")
public class EditEventServlet extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("currentUser") == null) {
            response.sendRedirect("login.jsp");
            return;
        }
        
        User currentUser = (User) session.getAttribute("currentUser");
        
        // Check if user is admin
        if (!"Admin".equals(currentUser.getRole()) && !"admin".equals(currentUser.getRole())) {
            session.setAttribute("error", "Only administrators can edit events.");
            response.sendRedirect("eventServlet?action=list");
            return;
        }
        
        try {
            int eventId = Integer.parseInt(request.getParameter("id"));
            eventDAO dao = new eventDAO();
            Event event = dao.getEventById(eventId);
            
            if (event != null) {
                request.setAttribute("event", event);
                request.getRequestDispatcher("event_edit.jsp").forward(request, response);
            } else {
                request.setAttribute("errorMessage", "Event not found.");
                request.getRequestDispatcher("event_edit.jsp").forward(request, response);
            }
            
        } catch (NumberFormatException e) {
            request.setAttribute("errorMessage", "Invalid event ID.");
            request.getRequestDispatcher("event_edit.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Error loading event: " + e.getMessage());
            request.getRequestDispatcher("event_edit.jsp").forward(request, response);
        }
    }
}