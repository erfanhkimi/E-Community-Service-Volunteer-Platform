package controller;  // Or package filter; if you create filter package

import java.io.IOException;
import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.*;

@WebFilter("*.jsp")  // This filters all JSP files
public class AuthFilter implements Filter {
    
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // Initialization code if needed
    }
    
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;
        HttpSession session = req.getSession(false);
        
        String path = req.getServletPath();
        System.out.println("AuthFilter: Checking access to " + path);
        
        // List of public pages that don't require authentication
        String[] publicPages = {
            "/login.jsp",
            "/register.jsp", 
            "/index.html",
            "/test.jsp",
            "/testForward.jsp",
            "/diag.jsp",
            "/debug.jsp",
            "/checkSchema.jsp",
            "/testDataFixed.jsp"
        };
        
        // Check if current path is public
        boolean isPublicPage = false;
        for (String publicPage : publicPages) {
            if (path.equals(publicPage)) {
                isPublicPage = true;
                break;
            }
        }
        
        // Allow public pages
        if (isPublicPage) {
            System.out.println("AuthFilter: Allowing public page " + path);
            chain.doFilter(request, response);
            return;
        }
        
        // Check authentication for protected pages
        if (session == null || session.getAttribute("currentUser") == null) {
            System.out.println("AuthFilter: No user session, redirecting to login");
            res.sendRedirect(req.getContextPath() + "/login.jsp");
            return;
        }
        
        // Special handling for dashboard.jsp - redirect to servlet
        if (path.equals("/dashboard.jsp")) {
            System.out.println("AuthFilter: Redirecting dashboard.jsp to servlet");
            res.sendRedirect(req.getContextPath() + "/dashboard");
            return;
        }
        
        // User is authenticated, allow access
        System.out.println("AuthFilter: User authenticated, allowing " + path);
        chain.doFilter(request, response);
    }
    
    @Override
    public void destroy() {
        // Cleanup code if needed
    }
}