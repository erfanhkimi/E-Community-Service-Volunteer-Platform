package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import model.User;
import model.userDAO;

@WebServlet("/markAttendance")
public class MarkAttendanceServlet extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("currentUser") == null) {
            response.sendRedirect("login.jsp");
            return;
        }
        
        User user = (User) session.getAttribute("currentUser");
        
        try {
            int registrationId = Integer.parseInt(request.getParameter("registrationId"));
            String status = request.getParameter("status"); // "Attended" or "No-Show"
            
            userDAO dao = new userDAO();
            
            // Verify this registration belongs to the current user
            boolean canUpdate = dao.verifyUserRegistration(user.getId(), registrationId);
            
            if (canUpdate) {
                boolean success = dao.updateAttendance(registrationId, status);
                
                if (success) {
                    if ("Attended".equals(status)) {
                        // Get event hours and update user's total hours
                        double eventHours = dao.getEventHoursByRegistration(registrationId);
                        dao.updateUserHours(user.getId(), eventHours);
                        session.setAttribute("message", "✅ Marked as attended! " + eventHours + " hours added to your total.");
                    } else {
                        session.setAttribute("message", "❌ Marked as no-show.");
                    }
                } else {
                    session.setAttribute("error", "Failed to update attendance.");
                }
            } else {
                session.setAttribute("error", "You cannot update this registration.");
            }
            
            response.sendRedirect("dashboard");
            
        } catch (Exception e) {
            e.printStackTrace();
            session.setAttribute("error", "Error: " + e.getMessage());
            response.sendRedirect("dashboard");
        }
    }
}