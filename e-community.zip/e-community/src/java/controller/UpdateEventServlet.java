package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import model.Event;
import model.User;
import model.eventDAO;

@WebServlet("/updateEvent")
public class UpdateEventServlet extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("currentUser") == null) {
            response.sendRedirect("login.jsp");
            return;
        }
        
        User currentUser = (User) session.getAttribute("currentUser");
        
        // Check if user is admin
        if (!"Admin".equals(currentUser.getRole()) && !"admin".equals(currentUser.getRole())) {
            session.setAttribute("error", "Only administrators can update events.");
            response.sendRedirect("eventServlet?action=list");
            return;
        }
        
        try {
            int eventId = Integer.parseInt(request.getParameter("eventId"));
            String eventName = request.getParameter("eventName");
            String eventDate = request.getParameter("eventDate");
            String location = request.getParameter("location");
            String description = request.getParameter("description");
            double eventHours = Double.parseDouble(request.getParameter("eventHours"));
            
            // Validate input
            if (eventName == null || eventName.trim().isEmpty() ||
                eventDate == null || eventDate.trim().isEmpty() ||
                location == null || location.trim().isEmpty()) {
                request.setAttribute("errorMessage", "All required fields must be filled.");
                request.getRequestDispatcher("event_edit.jsp").forward(request, response);
                return;
            }
            
            Event event = new Event();
            event.setId(eventId);
            event.setEventName(eventName);
            event.setEventDate(eventDate);
            event.setLocation(location);
            event.setDescription(description);
            event.setEventHours(eventHours);
            
            eventDAO dao = new eventDAO();
            boolean success = dao.updateEvent(event);
            
            if (success) {
                session.setAttribute("message", "Event updated successfully!");
                response.sendRedirect("eventServlet?action=list");
            } else {
                request.setAttribute("errorMessage", "Failed to update event. Please try again.");
                request.getRequestDispatcher("event_edit.jsp").forward(request, response);
            }
            
        } catch (NumberFormatException e) {
            request.setAttribute("errorMessage", "Invalid hours value.");
            request.getRequestDispatcher("event_edit.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Error updating event: " + e.getMessage());
            request.getRequestDispatcher("event_edit.jsp").forward(request, response);
        }
    }
}