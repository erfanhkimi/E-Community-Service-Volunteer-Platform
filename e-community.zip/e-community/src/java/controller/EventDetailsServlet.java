package controller;

import java.io.IOException;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import model.Event;
import model.User;
import model.eventDAO;
import model.userDAO;

@WebServlet("/eventDetails")
public class EventDetailsServlet extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("currentUser") == null) {
            response.sendRedirect("login.jsp");
            return;
        }
        
        try {
            int eventId = Integer.parseInt(request.getParameter("id"));
            User user = (User) session.getAttribute("currentUser");
            
            eventDAO eDao = new eventDAO();
            userDAO uDao = new userDAO();
            
            // Get event details
            Event event = eDao.getEventById(eventId);
            
            if (event != null) {
                request.setAttribute("event", event);
                
                // Check if user is registered for this event
                Map<String, Object> registration = uDao.getUserEventRegistration(user.getId(), eventId);
                if (registration != null) {
                    request.setAttribute("registrationStatus", registration.get("status"));
                    request.setAttribute("registrationId", registration.get("registrationId"));
                }
                
                request.getRequestDispatcher("eventDetails.jsp").forward(request, response);
            } else {
                request.setAttribute("error", "Event not found");
                request.getRequestDispatcher("eventDetails.jsp").forward(request, response);
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Error loading event details");
            request.getRequestDispatcher("eventDetails.jsp").forward(request, response);
        }
    }
}