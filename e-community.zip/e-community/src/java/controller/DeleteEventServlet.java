package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import model.User;
import model.eventDAO;

@WebServlet("/deleteEvent")
public class DeleteEventServlet extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("currentUser") == null) {
            response.sendRedirect("login.jsp");
            return;
        }
        
        User currentUser = (User) session.getAttribute("currentUser");
        
        // Check if user is admin
        if (!"Admin".equals(currentUser.getRole()) && !"admin".equals(currentUser.getRole())) {
            session.setAttribute("error", "Only administrators can delete events.");
            response.sendRedirect("eventServlet?action=list");
            return;
        }
        
        try {
            int eventId = Integer.parseInt(request.getParameter("eventId"));
            eventDAO dao = new eventDAO();
            boolean success = dao.deleteEvent(eventId);
            
            if (success) {
                session.setAttribute("message", "Event deleted successfully!");
            } else {
                session.setAttribute("error", "Failed to delete event.");
            }
            
            response.sendRedirect("eventServlet?action=list");
            
        } catch (NumberFormatException e) {
            session.setAttribute("error", "Invalid event ID.");
            response.sendRedirect("eventServlet?action=list");
        } catch (Exception e) {
            e.printStackTrace();
            session.setAttribute("error", "Error deleting event: " + e.getMessage());
            response.sendRedirect("eventServlet?action=list");
        }
    }
}