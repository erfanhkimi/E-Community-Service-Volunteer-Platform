package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import model.User;
import model.userDAO;

@WebServlet("/cancelRegistration")
public class CancelRegistrationServlet extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        User user = (User) session.getAttribute("currentUser");
        
        if (user == null) {
            response.sendRedirect("login.jsp");
            return;
        }
        
        try {
            int registrationId = Integer.parseInt(request.getParameter("id"));
            userDAO dao = new userDAO();
            
            // Verify this registration belongs to the current user
            boolean canCancel = dao.verifyUserRegistration(user.getId(), registrationId);
            
            if (canCancel) {
                boolean success = dao.cancelRegistration(registrationId);
                if (success) {
                    session.setAttribute("message", "Registration cancelled successfully");
                } else {
                    session.setAttribute("error", "Failed to cancel registration");
                }
            } else {
                session.setAttribute("error", "You cannot cancel this registration");
            }
            
            response.sendRedirect("dashboard");
            
        } catch (Exception e) {
            e.printStackTrace();
            session.setAttribute("error", "Error: " + e.getMessage());
            response.sendRedirect("dashboard");
        }
    }
}