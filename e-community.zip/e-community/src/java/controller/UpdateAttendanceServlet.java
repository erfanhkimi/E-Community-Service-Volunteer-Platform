package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import model.User;
import model.userDAO;

@WebServlet("/updateAttendance")
public class UpdateAttendanceServlet extends HttpServlet {
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        User user = (User) session.getAttribute("currentUser");
        
        if (user == null) {
            response.sendRedirect("login.jsp");
            return;
        }
        
        try {
            int registrationId = Integer.parseInt(request.getParameter("registrationId"));
            String status = request.getParameter("status");
            
            userDAO dao = new userDAO();
            
            // Verify ownership and update
            boolean success = dao.updateAttendance(registrationId, user.getId(), status);
            
            if (success) {
                session.setAttribute("message", "Attendance updated to: " + status);
            } else {
                session.setAttribute("error", "Failed to update attendance");
            }
            
            response.sendRedirect("dashboard");
            
        } catch (Exception e) {
            e.printStackTrace();
            session.setAttribute("error", "Error: " + e.getMessage());
            response.sendRedirect("dashboard");
        }
    }
}