package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import model.User;
import model.userDAO;

@WebServlet("/updateProfile")
public class UpdateProfileServlet extends HttpServlet {
    
    // In UpdateProfileServlet.java - doPost method
@Override
protected void doPost(HttpServletRequest request, HttpServletResponse response) 
        throws ServletException, IOException {
    
    HttpSession session = request.getSession(false);
    if (session == null || session.getAttribute("currentUser") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
    
    User currentUser = (User) session.getAttribute("currentUser");
    
    try {
        // Get form parameters (REMOVE PHONE)
        String fullName = request.getParameter("fullName");
        String email = request.getParameter("email");
        String address = request.getParameter("address");
        String currentPassword = request.getParameter("currentPassword");
        String newPassword = request.getParameter("newPassword");
        String confirmPassword = request.getParameter("confirmPassword");
        
        userDAO dao = new userDAO();
        
        // Verify current password
        if (!dao.verifyPassword(currentUser.getId(), currentPassword)) {
            session.setAttribute("error", "Current password is incorrect");
            response.sendRedirect("profile");
            return;
        }
        
        // Check if email is already taken by another user
        if (!currentUser.getEmail().equals(email) && dao.emailExists(email)) {
            session.setAttribute("error", "Email is already registered by another user");
            response.sendRedirect("profile");
            return;
        }
        
        // Validate new password if provided
        if (newPassword != null && !newPassword.trim().isEmpty()) {
            if (!newPassword.equals(confirmPassword)) {
                session.setAttribute("error", "New passwords do not match");
                response.sendRedirect("profile");
                return;
            }
            
            if (newPassword.length() < 6) {
                session.setAttribute("error", "New password must be at least 6 characters");
                response.sendRedirect("profile");
                return;
            }
            
            // Update password
            boolean passwordUpdated = dao.updatePassword(currentUser.getId(), newPassword);
            if (!passwordUpdated) {
                session.setAttribute("error", "Failed to update password");
                response.sendRedirect("profile");
                return;
            }
        }
        
        // Update profile information (REMOVE PHONE parameter)
        boolean profileUpdated = dao.updateProfile(currentUser.getId(), fullName, email, address);
        
        if (profileUpdated) {
            // Update session with new user data
            User updatedUser = dao.getUserById(currentUser.getId());
            session.setAttribute("currentUser", updatedUser);
            
            session.setAttribute("message", "Profile updated successfully!");
        } else {
            session.setAttribute("error", "Failed to update profile");
        }
        
        response.sendRedirect("profile");
        
    } catch (Exception e) {
        e.printStackTrace();
        session.setAttribute("error", "Error updating profile: " + e.getMessage());
        response.sendRedirect("profile");
    }
}
}