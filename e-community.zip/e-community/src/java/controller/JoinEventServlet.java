package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.DBConnection;
import model.User;
import model.userDAO;

@WebServlet("/joinEvent")
public class JoinEventServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("currentUser");

        if (currentUser == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        int eventId = Integer.parseInt(request.getParameter("eventId"));
        int userId = currentUser.getId();
        userDAO dao = new userDAO(DBConnection.getConnection());

        // Check if already has an ACTIVE registration
        if (dao.isAlreadyRegistered(userId, eventId)) {
            // Redirect back with an 'already_joined' message
            response.sendRedirect("eventServlet?action=list&msg=already_joined");
            return; 
        }

        // NEW: Check if user has a CANCELLED registration for this event
        if (dao.hasCancelledRegistration(userId, eventId)) {
            // Reactivate the cancelled registration instead of creating new one
            boolean reactivated = dao.reactivateRegistration(userId, eventId);
            
            if (reactivated) {
                response.sendRedirect("eventServlet?action=list&msg=reactivated");
            } else {
                response.sendRedirect("eventServlet?action=list&msg=error");
            }
            return;
        }

        // Proceed with new registration if no previous registration exists
        boolean success = dao.registerForEvent(userId, eventId);

        if (success) {
            response.sendRedirect("eventServlet?action=list&msg=success");
        } else {
            response.sendRedirect("eventServlet?action=list&msg=error");
        }
    }
}