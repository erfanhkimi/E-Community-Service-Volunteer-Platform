package controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import model.User;
import model.userDAO;

@WebServlet("/profile")
public class ProfileServlet extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("currentUser") == null) {
            response.sendRedirect("login.jsp");
            return;
        }
        
        User user = (User) session.getAttribute("currentUser");
        
        try {
            userDAO dao = new userDAO();
            
            // Get user profile information (if you have additional fields)
            User userProfile = dao.getUserById(user.getId());
            
            // Get user statistics
            Map<String, Object> userStats = getUserStatistics(user.getId(), dao);
            
            // Set request attributes
            request.setAttribute("userProfile", userProfile);
            request.setAttribute("userStats", userStats);
            
            request.getRequestDispatcher("profile.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Error loading profile");
            request.getRequestDispatcher("profile.jsp").forward(request, response);
        }
    }
    
    // In ProfileServlet.java - update getUserStatistics method
private Map<String, Object> getUserStatistics(int userId, userDAO dao) {
    Map<String, Object> stats = dao.getUserEventStats(userId);
    
    // Set default values if empty
    if (stats.isEmpty()) {
        stats.put("totalEvents", 0);
        stats.put("attendedEvents", 0);
        stats.put("noShowEvents", 0);
        stats.put("cancelledEvents", 0);
        stats.put("totalHours", 0);
        stats.put("upcomingEvents", 0);
    }
    
    return stats;
}
}