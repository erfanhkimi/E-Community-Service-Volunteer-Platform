package controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import model.User;
import model.userDAO;

@WebServlet("/attendance")
public class AttendanceServlet extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("currentUser") == null) {
            response.sendRedirect("login.jsp");
            return;
        }
        
        User user = (User) session.getAttribute("currentUser");
        
        try {
            userDAO dao = new userDAO();
            
            // Get user's events
            List<Map<String, Object>> userEvents = dao.getUserEvents(user.getId());
            
            // Calculate statistics
            double totalHours = 0;
            int attendedCount = 0;
            int noShowCount = 0;
            
            for (Map<String, Object> event : userEvents) {
                String status = (String) event.get("status");
                double hours = (Double) event.get("hours");
                
                if ("Attended".equals(status)) {
                    totalHours += hours;
                    attendedCount++;
                } else if ("No-Show".equals(status)) {
                    noShowCount++;
                }
            }
            
            // Set attributes
            request.setAttribute("userEvents", userEvents);
            request.setAttribute("totalHours", totalHours);
            request.setAttribute("attendedCount", attendedCount);
            request.setAttribute("noShowCount", noShowCount);
            
            request.getRequestDispatcher("attendance.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Error loading attendance history");
            request.getRequestDispatcher("attendance.jsp").forward(request, response);
        }
    }
}